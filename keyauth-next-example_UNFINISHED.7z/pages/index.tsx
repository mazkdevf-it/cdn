import type { NextPage } from 'next'
import Head from 'next/head'
import { Label, TextInput, Button, Spinner } from "flowbite-react";


const Home: NextPage = () => {
  return (
    <div>
      <Head>
        <title>KeyAuth Next Example</title>
        <meta name="description" content="KeyAuth Next Example, Created by mazkdevf" />
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <main className="flex flex-col items-center justify-center px-6 py-8 mx-auto md:h-screen lg:py-0">
        <h1 className="flex items-center mb-6 text-2xl font-semibold text-white text-center">
          KeyAuth Next Example
        </h1>


        <div className='w-full bg-white rounded-lg shadow dark:border md:mt-0 sm:max-w-md xl:p-0 dark:bg-gray-800 dark:border-gray-700'>
          <div className='p-6 space-y-4 md:space-y-6 sm:p-8'>
            <h1 className='text-xl font-bold leading-tight tracking-tight text-gray-900 md:text-2xl dark:text-white'>
              Sign in to your account
            </h1>
            <form className='space-y-4 md:space-y-6' method="post">
              <div>
                <div className="mb-2 block">
                  <Label
                    htmlFor="username"
                    value="Your username"
                  />
                </div>
                <TextInput
                  id="username"
                  type="email"
                  placeholder="example user"
                  required={true}
                />
              </div>
              <div>
                <div className="mb-2 block">
                  <Label
                    htmlFor="password"
                    value="Your password"
                  />
                </div>
                <TextInput
                  id="password"
                  type="password"
                  placeholder='••••••••'
                  required={true}
                />
              </div>

              <div>
                <div className="mb-2 block">
                  <Label
                    htmlFor="license_key"
                    value="Your License"
                  />
                </div>
                <TextInput
                  id="license_key"
                  type="text"
                  placeholder='XXXXX-XXXXX-XXXXX-XXXXX-XXXXX'
                  required={true}
                />
              </div>

              <button type="submit" name='login' className="w-full text-white bg-primary-600 hover:bg-primary-700 focus:ring-4 focus:outline-none focus:ring-primary-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center">
                Login
              </button>

              <button type="submit" name='register' className="w-full text-white bg-primary-600 hover:bg-primary-700 focus:ring-4 focus:outline-none focus:ring-primary-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center">
                Register
              </button>

              <button type="submit" name='upgrade' className="w-full text-white bg-primary-600 hover:bg-primary-700 focus:ring-4 focus:outline-none focus:ring-primary-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center">
                Upgrade
              </button>

              <button type="submit" name='license' className="w-full text-white bg-primary-600 hover:bg-primary-700 focus:ring-4 focus:outline-none focus:ring-primary-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center">
                License
              </button>
            </form>
          </div>
        </div >
      </main >
    </div >

  )
}

export default Home
